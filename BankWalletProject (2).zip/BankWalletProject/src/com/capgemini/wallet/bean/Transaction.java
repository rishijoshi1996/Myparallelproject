package com.capgemini.wallet.bean;

public class Transaction {

	private double amount;
	private double balance;
	
	
	public Transaction(){}
	
	
	public void printDetails (double amount,double balance){
		this.amount=amount;
		this.balance=balance;
	}

	@Override
	public String toString() {
		return "Transaction [amount=" + amount + ", balance=" + balance + "]";
	}
	
}
