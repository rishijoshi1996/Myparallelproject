package com.capgemini.wallet.dao;

import java.util.Map;

import com.capgemini.wallet.bean.AccountUser;



public interface IAccountUserDao {

	void storeIntoMap(AccountUser au); 
	Map<Integer, AccountUser> displayAccountUser();
	
	void storeIntoWalletMap(); 
	Map<Integer, AccountUser> displayWalletDetails();
	
	void showBalance();
	void depositMoney(double amount) ;
	void withdrawMoney(double amount);
	void fundTransfer();
	
}
