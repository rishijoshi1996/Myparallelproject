package com.capgemini.wallet.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

import com.capgemini.wallet.bean.AccountUser;
import com.capgemini.wallet.service.ValidateUserDetails;
import com.capgemini.wallet.service.WalletServices;

public class PaymentWallet {

	public static void main(String[] args) throws IOException {
		// declaring the variables

		String option;
		String name;
		String age;
		String Address;
		String Email;
		String option1;
		double amount;

		// creating objects of the classes

		ValidateUserDetails vud = new ValidateUserDetails();
		WalletServices ws = new WalletServices();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		Scanner sc = new Scanner(System.in);

		// method for registration
		while (true) {
			System.out
					.println("Welcome to Your Finance : \n1.Register For New Account \n2.Exit");
			option = br.readLine();
			boolean isValid = vud.validateChoice(option);
			if (isValid)
				break;
			else
				System.out.println("The choice should be 1 or 2 :");
		}
		if (option.equals("1")) {
			// name
			while (true) {
				System.out.println("Please Enter Your Name : ");
				name = br.readLine();
				boolean isValid = vud.validateUserName(name);
				if (isValid)
					break;
				else
					System.out
							.println("*The name should contain 1st letter capital*");

			}
			// age
			while (true) {

				System.out.println("Enter Your Age :");
				age = br.readLine();
				boolean isValid = vud.validateUserAge(age);
				if (isValid)
					break;
				else
					System.out
							.println("*You should be above 22 years for processing loan*");
			}

			// Address
			while (true) {
				System.out.println("Enter Your Address : ");
				Address = br.readLine();
				boolean isValid = vud.validateUserAddress(Address);
				if (isValid)
					break;
				else
					System.out.println("This cannot be blank ");

			}

			// Email

			while (true) {
				System.out.println("Enter Your Email : ");
				Email = br.readLine();
				boolean isValid = vud.validateUserEmailAddress(Email);
				if (isValid)
					break;
				else
					System.out
							.println("The email format is incorrect please re-enter with atleast one @ and .com");
			}

			AccountUser au = new AccountUser();
			au.setName(name);
			au.setAge(Integer.parseInt(age));
			au.setAddress(Address);
			au.setEmail(Email);
			vud.storeIntoMap(au);
			while (true) {
				System.out
						.println("What service would you like to opt today :");
				System.out.println("1.Show Balance");
				System.out.println("2.Deposit Money");
				System.out.println("3.Withdraw Money");
				System.out.println("4.Fund Transfer");
				System.out.println("5.Print Transactions");
				System.out.println("6.Exit");
				option1 = sc.next();
				int choice = Integer.parseInt(option1);
				switch (choice) {
				case 1:
					ws.showBalance();
					break;
				case 2:
					System.out.println("Please enter the amount you wish to deposit :");
					 amount= sc.nextDouble();
					ws.depositMoney(amount);
					break;
					
				case 3:
					System.out.println("Please enter the amount you wish to withdraw :");
					 amount= sc.nextDouble();
					ws.withdrawMoney(amount);
					break;
				case 4:
					System.out.println("Fund Transfer");
					break;
				case 5:
					System.out.println("Print Transactions");
					break;
				case 6:
					System.out.println("Thanks for choosing Your Finance");
					System.exit(0);
					break;
					
				default:
					System.out
							.println("Invalid choice please from the given choice ");
					break;
				}

			}
		}

		// main choice
		else if (option.equals("2")) {
			System.out.println("Thanks for your intrest");
		}

	}
}