package com.capgemini.wallet.service;

public interface IWalletServices {

	void showBalance();
	void depositMoney(double amount);
	void withdrawMoney(double amount);
	void fundTransfer();
}
