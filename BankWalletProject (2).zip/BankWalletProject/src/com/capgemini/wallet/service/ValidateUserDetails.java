package com.capgemini.wallet.service;

import java.util.Map;

import com.capgemini.wallet.bean.AccountUser;
import com.capgemini.wallet.dao.AccountUserDao;



public class ValidateUserDetails implements IValidateUserDetails {

	AccountUserDao aud = new AccountUserDao();

	@Override
	public boolean validateUserName(String userName) {
		if (userName.matches(userNamePattern))
			return true;
		else
			return false;
	}

	@Override
	public boolean validateUserAge(String userAge) {

		if (userAge.matches(userAgePattern) && Integer.parseInt(userAge) >= 22)
			return true;
		else
			return false;
	}

	@Override
	public boolean validateUserAddress(String userAddress) {
		if (userAddress.matches(userAddressPattern))
			return true;
		else
			return false;
	}

	@Override
	public boolean validateUserEmailAddress(String userAddress) {
		if (userAddress.matches(userEmailAddressPattern))
			return true;
		else
			return false;
	}

	
	@Override
	public boolean validateChoice(String option) {
		if (option.matches(CHOICE))
			return true;
		else
		return false;
	}
	@Override
	public boolean validateChoice1(String option1) {
		if (option1.matches(CHOICE1))
			return true;
		else
		return false;
	}

	@Override
	public void storeIntoMap(AccountUser au) {
		aud.storeIntoMap(au);
		
	}

	@Override
	public Map<Integer, AccountUser> displayCustomer() {
		
		return null;
	}

	

}
