package com.capgemini.wallet.service;

import com.capgemini.wallet.bean.AccountUser;
import com.capgemini.wallet.dao.AccountUserDao;

public class WalletServices implements IWalletServices {

	AccountUser au = new AccountUser();
	AccountUserDao aud = new AccountUserDao();
	
	@Override
	public void showBalance() {
		aud.showBalance();
		
	}

	@Override
	public void depositMoney(double amount) {
		aud.depositMoney(amount);
		
	}

	@Override
	public void withdrawMoney(double amount) {
		aud.withdrawMoney(amount);
		
	}

	@Override
	public void fundTransfer() {
		
		
		
	}

}
