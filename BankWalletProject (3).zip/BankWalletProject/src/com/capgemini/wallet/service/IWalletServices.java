package com.capgemini.wallet.service;

public interface IWalletServices {

	void storeIntoMap();

	void showBalance();

	void createUser(String name, String age, String address, String email);

	void depositMoney(double amount);

	void withdrawMoney(double amount);

	void fundTransfer(double amount);

	void printTransaction();

}
