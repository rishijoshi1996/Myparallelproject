package com.capgemini.wallet.bean;

public class Transaction {

	private double amount;
	private double balance;
	private String type;
	
	
	public Transaction(double amount, double balance, String type) {
		super();
		this.amount = amount;
		this.balance = balance;
		this.type = type;
	}

	public Transaction() {
	}

	public String printDetails() {
		return "Transaction [amount=" + amount + ", balance=" + balance + "]";
	}
	
}
