import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class TrialTest {

	TrialDao dao = null;

	@Before
	public void setUp() {
		dao = new TrialDao();

	}

	@After
	public void breakDown() {
		dao = null;
	}

	@Test
	public void testDao() {
		TrialBean bean = new TrialBean();
		TrialBean req = new TrialBean();

		bean.setBalance(1000);
		bean.setId(101);
		bean.setName("Sushen");
		dao.storeInToList(bean);
		//String name = bean.getName();
		req = dao.searchName(bean);
		Assert.assertNotNull(req);
	}
	@Test
	public void testInvalidDao() {
		TrialBean bean = new TrialBean();
		TrialBean req = new TrialBean();

		bean.setBalance(1000);
		bean.setId(102);
		bean.setName("Mayuresh");
		//dao.storeInToList(bean);
		//String name = bean.getName();
		req = dao.searchName(bean);
		Assert.assertNull(req);
	}
}
