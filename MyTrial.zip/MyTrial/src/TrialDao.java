import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.Vector;

public class TrialDao {
	TrialBean t1 = new TrialBean();

	protected TransactionsSummary[] txns;

	protected int idx;

	static Map<Integer, TrialBean> mapDet = new HashMap<Integer, TrialBean>();

	static Map<Integer, Double> mapBal = new HashMap<Integer, Double>();

	static Set<TrialBean> mySet = new HashSet<TrialBean>();

	static Set<TrialBean> myLSet = new LinkedHashSet<TrialBean>();

	static Set<TrialBean> myTSet = new TreeSet<TrialBean>();

	static List<TrialBean> list = new Vector<TrialBean>();

	public void storeInToList(TrialBean bean) {
		list.add(bean);
	}

	public List<TrialBean> displayList(int find) {
		for (TrialBean trialBean : list) {
			if(trialBean.getId()==find){
				
			}
			
		}
		
		return list;

	}

	public void storeInSet(TrialBean bean) {
		myTSet.add(bean);
	}

	public Set<TrialBean> displaySet() {
		return myTSet;

	}

	public void storeDetails(String name, int id) {

		t1.setName(name);
		t1.setId(id);
		mapDet.put(t1.getId(), t1);

	}

	public void storeBal(Double amount) {
		mapBal.put(t1.getId(), amount);
		mapDet.put(t1.getId(), t1);

	}

	public void deleteAccount() {
		System.out.println("Before\n" + mapDet);
		mapDet.remove(t1.getId());
		System.out.println("Account removed\n" + mapDet);
	}

	public void displayBal() {
		System.out.println("Display balance " + mapBal.get(t1.getId()));
		for (int i = 0; i < idx; i++)
			System.out.println(txns[i].print());

	}

	public void displayDetails() {
		System.out.println("Display details " + mapDet.get(t1.getId()));
	}

	TrialBean searchName(TrialBean bean) {

		for (TrialBean tb : list) {
			if (tb.getName() == bean.getName())
				return bean;
		}
		return null;
	}

}
