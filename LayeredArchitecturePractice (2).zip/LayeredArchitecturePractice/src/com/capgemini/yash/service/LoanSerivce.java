package com.capgemini.yash.service;

import java.util.ArrayList;

import com.capgemini.yash.bean.Loan;
import com.capgemini.yash.dao.LoanDao;

public class LoanSerivce implements LoanServiceI {
	LoanDao loandao=new LoanDao();
	private double emiAmount;
	private double temp;
	private double temp1;
		@Override
		public void applyLoan(Loan loan) {
			loandao.applyLoan(loan);
		}

		@Override
		public double calculateEMI(double amount, int duration) {
			emiAmount = (amount* interestRate * Math.pow(1 + interestRate, duration)) / (Math.pow(1 + interestRate, duration) - 1); 
			return emiAmount;
			
		}

		@Override
		public ArrayList<Loan> displayLoan() {
			return loandao.displayLoan();
		}

		public void setLoanAmount(double loanAmount) {
			
			
		}
}
