package com.capgemini.yash.service;

import java.util.Map;

import com.capgemini.yash.bean.Customer;
import com.capgemini.yash.exception.RecordNotFoundException;

public interface Validate {

	String userNamePattern = "[A-Z a-z]{1,9}";
	String userAgePattern = "[1-9]{2}";
	String userAddressPattern = "[A-Z a-z 0-9]{1,50}";
	String userEmailAddressPattern = "[A-Z a-z]{1,10}[@]{1}[A-Z a-z]{3,15}[.]{1}[c,o,m]{3}";
	String LOAN_AMOUNT = "[0-9]{1,8}";
	String LOAN_DURATION = "[0-9]{1}";
	String CHOICE = "[1-2]{1}";
	String CHOICE1 = "[1-2]{1}";

	boolean validateUserName(String userName);

	boolean validateUserAge(String userAge);

	boolean validateUserAddress(String userAddress);

	boolean validateUserEmailAddress(String userEmailAddress);

	boolean validateLOAN_AMOUNT(String loanAmount);

	boolean validateLOAN_DURATION(String loanDuration);

	boolean validateChoice(String option);

	boolean validateChoice1(String option1);

	void storeIntoMap(Customer customer);
	
	Customer find(int id) throws RecordNotFoundException;

	// public abstract
	Map<Integer, Customer> displayCustomer();

}
