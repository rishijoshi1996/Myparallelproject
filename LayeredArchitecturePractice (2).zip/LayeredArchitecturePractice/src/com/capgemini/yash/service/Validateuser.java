package com.capgemini.yash.service;

import java.util.Map;

import com.capgemini.yash.bean.Customer;
import com.capgemini.yash.dao.CustomerDao;
import com.capgemini.yash.exception.RecordNotFoundException;

public class Validateuser implements Validate {

	CustomerDao cd = new CustomerDao();

	@Override
	public boolean validateUserName(String userName) {
		if (userName.matches(userNamePattern))
			return true;
		else
			return false;
	}

	@Override
	public boolean validateUserAge(String userAge) {

		if (userAge.matches(userAgePattern) && Integer.parseInt(userAge) >= 22)
			return true;
		else
			return false;
	}

	@Override
	public boolean validateUserAddress(String userAddress) {
		if (userAddress.matches(userAddressPattern))
			return true;
		else
			return false;
	}

	@Override
	public boolean validateUserEmailAddress(String userEmailAddress) {
		if (userEmailAddress.matches(userEmailAddressPattern))
			return true;
		else
			return false;
	}

	@Override
	public boolean validateLOAN_AMOUNT(String loanAmount) {
		if (loanAmount.matches(LOAN_AMOUNT))
			return true;
		else
			return false;
	}

	@Override
	public boolean validateLOAN_DURATION(String loanDuration) {
		if (loanDuration.matches(LOAN_DURATION))
			return true;
		else
			return false;
		
	}
	
	public boolean validateChoice(String option) {
		if (option.matches(CHOICE))
			return true;
		else
		return false;
	}
	
	public boolean validateChoice1(String option1) {
		if (option1.matches(CHOICE1))
			return true;
		else
		return false;
	}

	@Override
	public void storeIntoMap(Customer customer) {
		cd.storeIntoMap(customer);

	}

	@Override
	public Map<Integer, Customer> displayCustomer() {
		return cd.displayCustomer();
	}

	public Customer find(int id) throws RecordNotFoundException {
		
		return cd.find(id);
	}

	

}
