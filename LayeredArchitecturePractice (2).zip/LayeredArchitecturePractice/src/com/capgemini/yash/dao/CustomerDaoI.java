package com.capgemini.yash.dao;

import java.util.Map;

import com.capgemini.yash.bean.Customer;
import com.capgemini.yash.exception.RecordNotFoundException;

public interface CustomerDaoI {
	void storeIntoMap(Customer customer1); 
	Map<Integer, Customer> displayCustomer();

	Customer find(int id) throws RecordNotFoundException;
}
