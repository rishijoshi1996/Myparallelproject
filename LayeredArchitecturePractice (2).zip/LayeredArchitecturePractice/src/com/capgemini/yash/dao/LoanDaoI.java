package com.capgemini.yash.dao;

import java.util.ArrayList;

import com.capgemini.yash.bean.Loan;

public interface LoanDaoI {

	void applyLoan (Loan loan);
	 ArrayList<Loan> displayLoan();
}
