package com.capgemini.yash.dao;

import java.util.HashMap;
import java.util.Map;





import com.capgemini.yash.bean.Customer;
import com.capgemini.yash.exception.RecordNotFoundException;



public class CustomerDao implements CustomerDaoI {

	private Map<Integer,Customer> customer1 =new 
			HashMap<Integer,Customer>();
	
	@Override
	public void storeIntoMap(Customer customer) {
		int code=(int) (Math.random()*1000);
		customer.setCode(code);
		customer1.put(code, customer);
		System.out.println("your customer Id is :"+code);
		
	}

	@Override
	public Map<Integer, Customer> displayCustomer() {
		
		return customer1;
	}
public Customer find(int id) throws RecordNotFoundException
{
	Customer cust=customer1.get(id);
	if(cust!=null)
	return cust;
	else
		throw new RecordNotFoundException("Record not fount please register");
	}
		
}
