import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class CountCharMap {
	public static Map countCharacter(char... arr) {
		HashMap<Character, Integer> map = new HashMap<Character, Integer>();
		int count;
for(int i=0;i<arr.length;i++)
{
	count=0;
	for(int j=0;j<arr.length;j++)
	{
		if(arr[i]==arr[j])
			count++;
	}
	map.put(arr[i], count);
}
		return map;

	}

	public static void main(String[] args) {
//		Scanner sc = new Scanner(System.in);
//		System.out.println("How Many character you want to enter");
//		int len = sc.nextInt();
//		char[] arr = new char[len];
//		System.out.println("Enter Charcter one by one");
//		for (int i = 0; i < len; i++)
//			arr[i] = sc.next().charAt(0);
		System.out.println(countCharacter('A','P','P','L','E'));
	}
}
