import java.awt.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;

public class SortByHash {
	public static ArrayList<Integer> getValues(HashMap map) {
		System.out.println(map);
		ArrayList<Integer> lst = new ArrayList<Integer>(map.values());
		Collections.sort(lst);
		return lst;
	}

	public static void main(String[] args) {
		HashMap<Integer, Integer> map = new HashMap<>();
		map.put(1, 99);
		map.put(2, 44);
		map.put(3, 33);
		map.put(4, 22);
		map.put(5, 55);
		System.out.println(getValues(map));

	}
}
