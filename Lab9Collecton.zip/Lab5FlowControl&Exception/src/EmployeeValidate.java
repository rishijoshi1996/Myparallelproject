class EmpException extends Exception {
	public EmpException() {
	}

	public EmpException(String msg) {
		super(msg);
	}

}

class Employee {
	String firstName;
	String lastName;

	public Employee() {

	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public Employee(String firstName, String lastName) {
		this.firstName = firstName;
		this.lastName = lastName;
	}

	public void validateName() throws EmpException {
		if ((this.firstName != null && this.firstName.indexOf(" ") != 0)
				&& (this.lastName != null && this.lastName.indexOf(" ") != 0))
			System.out.println("Employee is validate");
		else
			throw new EmpException("Enter valid name");
	}
}

public class EmployeeValidate {
	public static void main(String[] args) {
		Employee emp = new Employee("Mayuresh", "Shinde");
		// System.out.println(emp.getLastName().indexOf(" "));
		try {
			emp.validateName();
		} catch (EmpException e) {
			System.out.println(e.getMessage());
		}

	}
}
