import com.cg.eis.exception.EmployeeException;

class Emp {
	int id;
	String name;
	double salary;

	public Emp() {
	}

	public Emp(int id, String name, double salary) {
		this.id = id;
		this.name = name;
		this.salary = salary;
	}

	public double getSalary() {
		return salary;
	}

	@Override
	public String toString() {

		return "ID :" + id + "\nName :" + name + "\nSalary :" + salary;
	}

	public void checkSalary() throws EmployeeException {
		if (getSalary() > 15000)
			System.out.println(this);
		else
			throw new EmployeeException("Your salary is less than 1500");
	}

}

public class EmpSalary {
	public static void main(String[] args) {
	
		Emp emp=new Emp(7778,"Mayuresh",1500);
		try
		{
		emp.checkSalary();
		}catch (EmployeeException e) {
			System.out.println(e);
		}
		}
}
