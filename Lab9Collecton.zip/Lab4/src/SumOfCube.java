import java.util.Scanner;


public class SumOfCube {
	public static void cubeSum(int num)
	{
		double sum = 0;
		for(int i=0;i<=num;i++)
		{
			sum+=Math.pow(i,3);
		}
		System.out.println("sum of the cubes of the digits upto "+num+" :" +sum);
	}
	
public static void main(String[] args) {
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter number");
	int num =sc.nextInt();
	cubeSum(num);
	
}
}
