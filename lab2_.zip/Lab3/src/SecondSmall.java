import java.util.Collection;
import java.util.Scanner;


public class SecondSmall {
	public int getSecondSmallest (int ... arr)
	{
		int temp=0;
		for( int i=1; i<arr.length;i++)
		{
			for(int j=1; j<arr.length;j++)
			if(arr[j]<arr[j-1])
			{
				temp=arr[j];
				arr[j]=arr[j-1];
				arr[j-1]=temp;
			}
		}
		return arr[1];
	}
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter n number");
	int n=sc.nextInt();
	int[] arr= new int[n];
	
	for(int i=0;i<arr.length;i++){
		System.out.println("Enter "+i+" Number");
		arr[i]=sc.nextInt();
	}
	
	/*for(int num:arr)
		System.out.print(num+"\t");
*/
	SecondSmall ss= new SecondSmall();
	System.out.println("Second Smallest Number : "+ss.getSecondSmallest(arr));
}
}
