import java.util.Arrays;
import java.util.Scanner;

public class SortNo {
	public static void getSorted(int... arr) {
String sarr=Arrays.toString(arr);
System.out.println("In starting :"+sarr);
String reverse="";
for(int i=sarr.length()-2;i>0;i--)
	reverse+=sarr.charAt(i);
System.out.println("Reverse : "+reverse);
String[] rrr= reverse.replaceAll("\\[", "").replaceAll("\\]", "").replaceAll("\\s", "").split(",");
String temp="";
int[] rev=new int[rrr.length];

for( int i=0; i<rrr.length;i++)
{
	for(int j=1; j<rrr.length;j++)
	if(Integer.parseInt(rrr[j])<Integer.parseInt(rrr[j-1]))
	{
		temp=rrr[j];
		rrr[j]=rrr[j-1];
		rrr[j-1]=temp;
	}
	
}
System.out.println("---After sorting---");
for(int i=0;i<rrr.length;i++)
{
rev[i]=Integer.parseInt(rrr[i]);	
}
		for (int i : rev) {
			System.out.println(i);
		}

	}

	public static void main(String[] args) {
//		Scanner sc = new Scanner(System.in);
//		System.out.println("How Many Number you want to enter");
//		int len = sc.nextInt();
//		int[] arr = new int[len];
//		System.out.println("Enter Number one by one");
//		for (int i = 0; i < len; i++)
//			arr[i] = sc.nextInt();
//		getSorted(arr);
//		System.out.println("------------");
		getSorted(22,42,52,82,72,22);
	}
}
