public class CountChar {
	public static void countCharacter(char... arr) {
		int count;
		String find = "";
		int[] charCount = new int[arr.length];
		for (char i : arr) {
			find += i;
		}
		for (int i = 0; i < arr.length; i++) {
			count = 0;
			for (int j = 0; j < arr.length; j++) {
				if (arr[i] == arr[j]) {
					count++;
					
				}
				
				charCount[i] = count;
			}

			// System.out.println(arr[i]+" : "+ count);
		}
//		for (int i : charCount) {
//			System.out.println(i);
//		}
		System.out.println(find);
		boolean flag=false;
		for (int i = 0; i < arr.length; i++) {
			
			for (int j = 0; j <i; j++) {
				if (arr[i] == find.charAt(j))
					flag = true;
			}
			if (!flag)
				System.out.println(arr[i] + " : " + charCount[i]);
			flag = false;
		}
	}

	public static void main(String[] args) {
		// Scanner sc = new Scanner(System.in);
		// System.out.println("How Many character you want to enter");
		// int len = sc.nextInt();
		// char[] arr = new char[len];
		// System.out.println("Enter Charcter one by one");
		// for (int i = 0; i < len; i++)
		// arr[i] = sc.next().charAt(0);
		countCharacter('A', 'P', 'P', 'L', 'E');
		System.out.println("--------");
		countCharacter('A','A','A','A','B','B','B','C','C','D','D');
		countCharacter('E','L','E','P','H','A','N','T');
		countCharacter('P','O','T','A','T','O');
		countCharacter('g','e','e','k','f','o','r','g','e','e','k','s');
	}
}