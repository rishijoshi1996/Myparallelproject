import java.util.Scanner;
class Sum
{
	Sum(){}
	public int calculateSum(int ... str)
	{
		int sum=0;
		for(int temp:str)
		{
			if(temp%3==0||temp%5==0)
				sum+=temp;
		}
		
		return sum;
	}
	
}

public class SumN {
	
	public static void main(String[] args) {
		Sum num = new Sum();
		int result=num.calculateSum(4,5,6,9,8,7,1,23,5);
		System.out.println(result);
		result=num.calculateSum(3,5,8,1);
		System.out.println(result);
		
	}

}
