class ChNo{
	
	ChNo(){}
boolean ChkNo(int num)
{
	boolean inc=true;
	String no="";
	int num1=0,num2=0;
	no = Integer.toString(num); 
	System.out.println(no);
	for(int ctr=1;ctr<no.length();ctr++)
	{
		num1=Character.getNumericValue(no.charAt(ctr));
		num2=Character.getNumericValue(no.charAt(ctr-1));
		if(num2>num1)
			inc=false;
	}
	return inc;
}
}
public class IncreasingNo {
public static void main(String[] args) {
	ChNo num= new ChNo();
	System.out.println(num.ChkNo(1234562));
	
}
}
