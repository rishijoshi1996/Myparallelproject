package com.capgemini.xyz.service;

import com.capgemini.xyz.bean.Employee;
import com.capgemini.xyz.dao.EmpDao;

public class ValidateUserInput implements ValidateInterface {
	EmpDao dao = new EmpDao();

	@Override
	public boolean validateUserName(String userName) {
		if (userName.matches(USER_NAME_PATTERN))
			return true;
		else
			return false;
	}

	@Override
	public boolean validateSalary(String salary) {
		if (salary.matches(SALARY))
			return true;
		else
			return false;
	}

	@Override
	public boolean validateChoice(String ch) {
		if (ch.matches(CHOICE))
			return true;
		else
			return false;
	}

	@Override
	public void storeToList(Employee emp) {
		dao.storeToList(emp);
	}

	public Employee showDetails(int id) {
		// TODO Auto-generated method stub
		return dao.showDetails(id);
	}

	@Override
	public boolean validateId(String id) {
		if (id.matches(ID))
			return true;
		else
			return false;
	}

}
