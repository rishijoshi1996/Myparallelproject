package com.capgemini.xyz.dao;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.capgemini.xyz.bean.Employee;

public class EmpDao implements EmpDaoInterface {
//	List<Employee> employee = new ArrayList<Employee>();
	Set<Employee> employ=new HashSet<Employee>();
	private static int code = 12301;

	@Override
	public void storeToList(Employee emp) {
		emp.setId(code);
		double salary = emp.getSalary();
		if (salary < 5000) {
			emp.setDesignation("Clerk");
			emp.setInsurance("No Scheme");
		} else if (5000 <= salary && salary < 20000) {
			emp.setDesignation("System Associate");
			emp.setInsurance("Scheme C");
		} else if (20000 <= salary && salary < 40000) {
			emp.setDesignation("Programmer");
			emp.setInsurance("Scheme B");
		} else {
			emp.setDesignation("Manager");
			emp.setInsurance("Scheme A");
		}
		//employee.add(emp);
		employ.add(emp);
		System.out.println("Information saves successfully.\nYour Id is "+code);
		code++;
	}

	public Employee showDetails(int id) {
		if (employ != null) {
			for (Employee emp : employ) {
				if (emp.equals(new Employee(id, null, 0, null)))
					return emp;
			}
		} else System.out.println("Record Not Found");;
		return null;
	}

}
