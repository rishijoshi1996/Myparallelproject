package lab13;

public class enterSpaceClasss {

	public static void main(String[] args) {
		
		EnterSpaceIn e=(x)->{x=x.replace(""," ").trim();return x;};
		System.out.println(e.enterSpace("durvesh"));
	}
}
