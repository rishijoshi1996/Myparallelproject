import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class ExecutorExecutorServices {
	
	public static void main(String[] args) {
		
		Executor executor= Executors.newSingleThreadExecutor();
		ExecutorService executor1= Executors.newSingleThreadExecutor();
		Runnable  rable = () -> {System.out.println("Hello, this is single thread pool");
									try {
										Thread.sleep(1000);
									} catch (InterruptedException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
			
			
			};
			System.out.println("This is Executor");
			executor.execute(rable);
			executor.execute(rable);

			System.out.println("This is Executor Service");
			executor1.execute(rable);
			executor1.shutdown();
			
			//executor.shutdown();
	}

}
