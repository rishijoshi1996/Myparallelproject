package com.capgemini.wallet.service;

import java.sql.SQLException;
import java.util.Map;

import com.capgemini.wallet.bean.AccountUser;
import com.capgemini.wallet.exception.WalletException;


public interface IWalletServices {

	String userNamePattern = "[A-Z a-z]{1,9}";
	String userAgePattern = "[1-9]{1,2}";
	String userAddressPattern = "[A-Z a-z 0-9]{1,50}";
	String userEmailAddressPattern = "[A-Z a-z]{1,10}[@]{1}[A-Z a-z]{3,15}[.]{1}[c,o,m]{3}";
	String CHOICE = "[1-3]{1}";
	String CHOICE1 = "[1-6]{1}";

	boolean validateUserName(String userName);

	boolean validateUserAge(String userAge);

	boolean validateUserAddress(String userAddress);

	boolean validateUserEmailAddress(String userEmailAddress);

	boolean validateChoice(String option);

	boolean validateChoice1(String option1);
	
	
	
	//wallet services
	
	double showBalance(int accno) throws WalletException;

	void depositMoney(double amount,int Accno) throws WalletException;

	void withdrawMoney(double amount,int Accno) throws WalletException;

	void fundTransfer(double amount, int accno, int Accno) throws WalletException;

	void printTransaction(int Accno) throws WalletException;

	

	void createUser(String name, String age, String address, String email) throws WalletException;

	

	
	
	//giving data to the Dao
	void storeIntoMap();
	
	

	// public abstract
	Map<Integer, AccountUser> displayCustomer();
	
	//check account number 
	boolean validateAccountNo(int Accno) throws WalletException;

	

	
	

}
