package com.capgemini.wallet.dao;

import java.util.Map;

import com.capgemini.wallet.bean.AccountUser;

public class AccountUserJdbcDao implements IAccountUserDao {

	@Override
	public void storeIntoMap() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Map<Integer, AccountUser> displayAccountUser() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void storeIntoWalletMap() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Map<Integer, AccountUser> displayWalletDetails() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void showBalance() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void depositMoney(double amount) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void withdrawMoney(double amount) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fundTransfer(double amount) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void createUser(String name, String age, String address, String email) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void printTransaction() {
		// TODO Auto-generated method stub
		
	}

}
