package com.capgemini.wallet.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.wallet.bean.AccountUser;
import com.capgemini.wallet.bean.Transaction;

public class AccountUserDao implements IAccountUserDao {

	AccountUser au = new AccountUser();

	private Map<Integer, AccountUser> Accuser = new HashMap<>();

	private Map<Integer, Double> Wallet = new HashMap<>();

	Transaction[] txns;
	int idxx;

	@Override
	public void createUser(String name, String age, String address, String email) {
		au.setName(name);
		au.setAge(Integer.parseInt(age));
		au.setAddress(address);
		au.setEmail(email);
		double amount = 0;
		txns = new Transaction[10];

//		txns[idxx++] = new Transaction("CR", au.getBalance(), amount);

	}

	@Override
	public void storeIntoMap() {
		int code = (int) (Math.random() * 1000);
		au.setCode(code);
		Accuser.put(code, au);
		System.out.println("Your account created successfully :");
		System.out.println("Your account number is " + au.getCode());
		System.out.println(Accuser);

	}

	@Override
	public Map<Integer, AccountUser> displayAccountUser() {

		return null;
	}

	@Override
	public void storeIntoWalletMap() {

		Wallet.put(au.getCode(), au.getBalance());

	}

	@Override
	public Map<Integer, AccountUser> displayWalletDetails() {

		return null;
	}

	@Override
	public void showBalance() {
		System.out.println("Your balance is :" + au.getBalance());

	}

	@Override
	public void depositMoney(double amount) {

		au.setBalance(amount + au.getBalance());
		Wallet.put(au.getCode(), au.getBalance());
		System.out.println(amount+"Rs. credited to you account"+au.getCode()+"successfully ");
		txns[idxx++] = new Transaction("CR",amount, au.getBalance());

	}

	@Override
	public void withdrawMoney(double amount) {

		if (amount > au.getBalance()) {
			System.out.println("Insufficient Funds :-( ");
		} else {
			au.setBalance(au.getBalance() - amount);
			Wallet.put(au.getCode(), au.getBalance());
			System.out
					.println(amount
							+ "\tWas Debited on your Account \nif the transaction was invalid please contact your branch soon  ");

			txns[idxx++] = new Transaction("DR", amount,au.getBalance());
		}

	}

	@Override
	public void fundTransfer(double amount) {

		if (amount > au.getBalance()) {
			System.out.println("Insufficient Funds :-( ");
		} else {
			au.setBalance(au.getBalance() - amount);
			Wallet.put(au.getCode(), au.getBalance());
			System.out
					.println(amount
							+ "\tWas Debited on your Account \nif the transaction was invalid please contact your branch soon  ");
			txns[idxx++] = new Transaction("FT",amount, au.getBalance());
		}

	}

	@Override
	public void printTransaction() {
		
		for(int i=0;i<idxx;i++){
			System.out.println(txns[i].printDetails());
			
		}
		

	}

}
