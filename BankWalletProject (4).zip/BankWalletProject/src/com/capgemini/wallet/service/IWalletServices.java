package com.capgemini.wallet.service;

import java.util.Map;

import com.capgemini.wallet.bean.AccountUser;


public interface IWalletServices {

	String userNamePattern = "[A-Z a-z]{1,9}";
	String userAgePattern = "[1-9]{1,2}";
	String userAddressPattern = "[A-Z a-z 0-9]{1,50}";
	String userEmailAddressPattern = "[A-Z a-z]{1,10}[@]{1}[A-Z a-z]{3,15}[.]{1}[c,o,m]{3}";
	String CHOICE = "[1-2]{1}";
	String CHOICE1 = "[1-6]{1}";

	boolean validateUserName(String userName);

	boolean validateUserAge(String userAge);

	boolean validateUserAddress(String userAddress);

	boolean validateUserEmailAddress(String userEmailAddress);

	boolean validateChoice(String option);

	boolean validateChoice1(String option1);
	
	
	
	//wallet services
	
	void showBalance();

	void depositMoney(double amount);

	void withdrawMoney(double amount);

	void fundTransfer(double amount);

	void printTransaction();

	

	void createUser(String name, String age, String address, String email);

	

	
	
	//giving data to the Dao
	void storeIntoMap();
	
	

	// public abstract
	Map<Integer, AccountUser> displayCustomer();
	

}
