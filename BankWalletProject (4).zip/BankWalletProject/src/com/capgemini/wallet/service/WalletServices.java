package com.capgemini.wallet.service;

import java.util.Map;

import com.capgemini.wallet.bean.AccountUser;
import com.capgemini.wallet.dao.AccountUserDao;



public class WalletServices implements IWalletServices {

	AccountUserDao aud = new AccountUserDao();

	@Override
	public boolean validateUserName(String userName) {
		if (userName.matches(userNamePattern))
			return true;
		else
			return false;
	}

	@Override
	public boolean validateUserAge(String userAge) {

		if (userAge.matches(userAgePattern) && Integer.parseInt(userAge) >= 22)
			return true;
		else
			return false;
	}

	@Override
	public boolean validateUserAddress(String userAddress) {
		if (userAddress.matches(userAddressPattern))
			return true;
		else
			return false;
	}

	@Override
	public boolean validateUserEmailAddress(String userAddress) {
		if (userAddress.matches(userEmailAddressPattern))
			return true;
		else
			return false;
	}

	
	@Override
	public boolean validateChoice(String option) {
		if (option.matches(CHOICE))
			return true;
		else
		return false;
	}
	@Override
	public boolean validateChoice1(String option1) {
		if (option1.matches(CHOICE1))
			return true;
		else
		return false;
	}

	@Override
	public void storeIntoMap() {
		aud.storeIntoMap();
		
	}

	@Override
	public Map<Integer, AccountUser> displayCustomer() {
		
		return null;
	}

	@Override
	public void createUser(String name, String age, String address, String email) {

		aud.createUser(name, age, address, email);
		
		
	}
	@Override
	public void showBalance() {
		aud.showBalance();

	}

	@Override
	public void depositMoney(double amount) {
		aud.depositMoney(amount);

	}

	@Override
	public void withdrawMoney(double amount) {
		aud.withdrawMoney(amount);

	}

	@Override
	public void fundTransfer(double amount) {
      aud.fundTransfer(amount);
	}

	@Override
	public void printTransaction() {
	aud.printTransaction();
		
	}
	

	

	

}
