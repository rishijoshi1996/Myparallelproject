package com.capgemini.yash.ui;

/*
 * create a class to accept user input
 * and validate (this is the main class) 
 */
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

import com.capgemini.yash.bean.Customer;
import com.capgemini.yash.bean.Loan;
import com.capgemini.yash.exception.RecordNotFoundException;
import com.capgemini.yash.service.LoanSerivce;
import com.capgemini.yash.service.Validateuser;
import com.capgemini.yash.utility.JdbcUtil;

public class EmployeeUI {

	
	public static void main(String[] args) throws IOException,
			RecordNotFoundException, SQLException {
	
		String option;
		String name;
		String age;
		String Address;
		String Email;
		String option1;
		String loanAmount;
		String loanDuration;
		Validateuser vu = new Validateuser();
		Loan loan = new Loan();
		LoanSerivce loansvc = new LoanSerivce();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		while (true) {
			System.out
					.println("Welcome to your Finance : \n1.Register For Loan \n2.Exit");
			option = br.readLine();
			boolean isValid = vu.validateChoice(option);
			if (isValid)
				break;
			else
				System.out.println("The choice should be 1 or 2 :");
		}
		if (option.equals("1")) {
			// name
			while (true) {
				System.out.println("Please Enter Your Name : ");
				name = br.readLine();
				boolean isValid = vu.validateUserName(name);
				if (isValid)
					break;
				else
					System.out
							.println("*The name should contain 1st letter capital*");

			}
			// age
			while (true) {

				System.out.println("Enter Your Age :");
				age = br.readLine();
				boolean isValid = vu.validateUserAge(age);
				if (isValid)
					break;
				else
					System.out
							.println("*You should be above 22 years for processing loan*");
			}

			// Address
			while (true) {
				System.out.println("Enter Your Address : ");
				Address = br.readLine();
				boolean isValid = vu.validateUserAddress(Address);
				if (isValid)
					break;
				else
					System.out.println("This cannot be blank ");

			}

			// Email

			while (true) {
				System.out.println("Enter Your Email : ");
				Email = br.readLine();
				boolean isValid = vu.validateUserEmailAddress(Email);
				if (isValid)
					break;
				else
					System.out
							.println("The email format is incorrect please re-enter with atleast one @ and .com");
			}

			Customer customer = new Customer();
			customer.setName(name);
			customer.setAge(Integer.parseInt(age));
			customer.setAddress(Address);
			customer.setEmail(Email);
			vu.storeIntoMap(customer);
			System.out.println("Your customer Id is generated successfully ");
			// System.out.println(vu.displayCustomer());
			while (true) {
				System.out
						.println("Do you wish to apply for loan : \n1.Yes \n2.No ");
				option1 = br.readLine();
				boolean isValid = vu.validateChoice1(option1);
				if (isValid)
					break;
				else
					System.out
							.println("The choice should be in between 1 or 2");
			}

			if (option1.equals("1")) {

				while (true) {

					System.out.println("Enter the loan amount");
					loanAmount = br.readLine();
					boolean isValid = vu.validateLOAN_AMOUNT(loanAmount);
					if (isValid)
						break;
					else
						System.out
								.println("The amount should be less than 1cr. and input digit between 0-9  and ");
				}

				while (true) {
					System.out.println("Enter the loan duration in years");
					loanDuration = br.readLine();
					boolean isValid = vu.validateLOAN_DURATION(loanDuration);
					if (isValid)
						break;
					else
						System.out
								.println("The duration should be less than 10 ");
				}

				loan.setLoanAmount(Double.parseDouble(loanAmount));
				loan.setDuration(Integer.parseInt(loanDuration));
				loan.setCustId(customer.getCode());
				loansvc.applyLoan(loan);
				System.out.println(vu.displayCustomer());
				System.out.println(loansvc.displayLoan());
				System.out.println(name
						+ " your EMI is"
						+ loansvc.calculateEMI(Double.parseDouble(loanAmount),
								Integer.parseInt(loanDuration) * 12));

			} else if (option1.equals("2")) {

				System.out.println(vu.displayCustomer());

			}
			System.out.println("enter cust id that you want to search : ");
			Scanner sc = new Scanner(System.in);
			int id = sc.nextInt();
			try {
				System.out.println(vu.find(id));
			} catch (RecordNotFoundException e) {
				e.printStackTrace();
			}
		} else if (option.equals("2")) {
			System.out.println("Thanks for your intrest");
		}

	}
}
