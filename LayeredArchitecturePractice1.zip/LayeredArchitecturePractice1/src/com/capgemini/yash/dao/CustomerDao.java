package com.capgemini.yash.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import com.capgemini.yash.bean.Customer;
import com.capgemini.yash.exception.RecordNotFoundException;
import com.capgemini.yash.utility.JdbcUtil;



public class CustomerDao implements CustomerDaoI {

	private Map<Integer,Customer> customer1 =new 
			HashMap<Integer,Customer>();
	Connection connection = null;
	PreparedStatement statement = null;
	
	@Override
	public void storeIntoMap(Customer customer) throws RecordNotFoundException {
		int code=(int) (Math.random()*1000);
		customer.setCode(code);
		customer1.put(code, customer);
		System.out.println("your customer Id is :"+code);
		try {
			connection=JdbcUtil.getConnection();
		} catch (ClassNotFoundException | RecordNotFoundException e1) {
			e1.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			try {
				statement = 
						connection.prepareStatement
						(QueryMapper.insertDetails);
			

				statement.setString(1, customer.getName() );
				statement.setInt(2, customer.getAge());
				statement.setString(3, customer.getAddress());
				statement.setString(4, customer.getEmail());
				statement.setInt(5, customer.getCode());
				

				statement.executeUpdate();
				

				
			} catch (SQLException e) {
				System.err.println("Unable to fetch data" + e);
				
			} finally {

				try {
					statement.close();
				} catch (SQLException e) {
				
					throw new RecordNotFoundException("unable to close statement object");
				}

				try {
					connection.close();
				} catch (SQLException e) {
				
					throw new RecordNotFoundException("unable to close connection object");
					}
			}
	}

	@Override
	public Map<Integer, Customer> displayCustomer() {
		
		return customer1;
	}
public Customer find(int id) throws RecordNotFoundException
{
	Customer cust=customer1.get(id);
	if(cust!=null)
	return cust;
	else
		throw new RecordNotFoundException("Record not fount please register");
	}
		
}
