package com.capgemini.yash.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.capgemini.yash.bean.Loan;

public class LoanDao implements LoanDaoI {

	private Map<Integer, Loan> loanEntry = new HashMap<Integer, Loan>();
	private int code;
	
	@Override
	public void applyLoan(Loan loan) {
		code = (int) (Math.random() * 1000);
		loan.setLoanID(code);
		loanEntry.put(code, loan);
		System.out.println("Your Loan request is generated.\nYour Loan ID is "
				+ code);
	}

	@Override
	public ArrayList<Loan> displayLoan() {
		ArrayList<Loan> lst1 = new ArrayList<Loan>(loanEntry.values());
		return lst1;
		
	}

}
