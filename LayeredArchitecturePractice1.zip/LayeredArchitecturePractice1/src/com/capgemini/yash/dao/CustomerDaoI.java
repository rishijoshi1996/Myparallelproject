package com.capgemini.yash.dao;

import java.sql.SQLException;
import java.util.Map;

import com.capgemini.yash.bean.Customer;
import com.capgemini.yash.exception.RecordNotFoundException;

public interface CustomerDaoI {
	void storeIntoMap(Customer customer1) throws RecordNotFoundException, SQLException; 
	Map<Integer, Customer> displayCustomer();

	Customer find(int id) throws RecordNotFoundException;
}
