package com.capgemini.yash.dao;

public interface QueryMapper {

	public static String insertDetails = "insert into Customer"
			+ "(name,age,Address,Email,code)" + " values" + "(?,?,?,?,?)";

}
