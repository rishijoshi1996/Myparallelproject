package com.capgemini.yash.test;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.yash.bean.Customer;
import com.capgemini.yash.dao.CustomerDao;
import com.capgemini.yash.exception.RecordNotFoundException;


public class ValidateuserTest {

	CustomerDao dao=null;
	
	@Before
	public void setUp() throws Exception {

		dao = new CustomerDao();
	}

	@After
	public void TearDown() throws Exception {
		dao = null;
	}
	
	@Test
	public void testValidCustomerDetails() throws RecordNotFoundException {
		Customer cust=new Customer();
		Customer requestCust=new Customer();
		cust.setAddress("Mumbai");
		cust.setAge(10);
		cust.setName("yash");
		cust.setEmail("yash@gam.com");
		dao.storeIntoMap(cust);
		int id = cust.getCode();
		try {
			requestCust = dao.find(id);
			Assert.assertNotNull(requestCust);
			System.out.println("test passed cust present");
		} catch (RecordNotFoundException e) {
System.out.println(e);
		}
	}
	
	@Test
	public void testInvalidCustomerDetails() throws RecordNotFoundException {
		Customer cust=new Customer();
		Customer requestCust=new Customer();
		cust.setAddress("Mumbai");
		cust.setAge(10);
		cust.setName("yash");
		cust.setEmail("yash@gam.com");
		dao.storeIntoMap(cust);
		
		try {
			requestCust = dao.find(12);
			Assert.assertNotNull(requestCust);
		} catch (RecordNotFoundException e) {
			System.out.println(e);
		}
	}
}
