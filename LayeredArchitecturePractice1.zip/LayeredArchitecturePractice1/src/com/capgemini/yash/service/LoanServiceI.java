package com.capgemini.yash.service;

import java.util.ArrayList;

import com.capgemini.yash.bean.Loan;

public interface LoanServiceI {

	double interestRate=9.5/(12*100);
	public void applyLoan(Loan loan);

	public double calculateEMI(double amount, int duration);

	ArrayList<Loan> displayLoan();
}
