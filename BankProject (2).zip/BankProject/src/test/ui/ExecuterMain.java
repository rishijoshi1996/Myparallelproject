package test.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

import test.service.ServiceClass;

public class ExecuterMain {
	public static void main(String[] args) throws IOException {

		ServiceClass service = new ServiceClass();
		Scanner sc = new Scanner(System.in);

		System.out.println("Welcome to XYZ payment wallet");

		System.out.println("1. Creat Account");
		System.out.println("2. Exit");

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		String choice;

		// Get user choice
		while (true) {
			System.out.println("Enter your choice");
			choice = br.readLine();

			boolean isValid = service.validateChoice(choice);
			if (isValid)
				break;
			else
				System.out.println("Please Enter porper choice ");
		}

		// When user input choice as 2
		if (2 == Integer.parseInt(choice)) {
			System.out.println("You are out of the application");
			System.out.println("\tThank You");
			System.exit(0);
		}

		System.out.println("Enter Your details to creat account ");
		// Get user Name
		String name;
		while (true) {
			System.out.println("Enter Your Name");
			name = br.readLine();
			boolean isValid = service.validateName(name);
			if (isValid)
				break;
			System.out.println("Enter First letter capital");

		}

		// Get User Address
		String address;

		while (true) {
			System.out.println("Enter your address");
			address = br.readLine();
			boolean isValid = service.validateAddress(address);
			if (isValid)
				break;

		}

		// Get Mobile number
		String mobile;

		while (true) {
			System.out.println("Enter your mobile");
			mobile = br.readLine();
			boolean isValid = service.validateMobile(mobile);
			if (isValid)
				break;
			System.out.println("Enter 10 digit mobile number");
		}

		// Get email
		String email;
		while (true) {
			System.out.println("Enter your email");
			email = br.readLine();
			boolean isValid = service.validateEmail(email);
			if (isValid)
				break;
			System.out.println("Enter email with @ and <domain>.com");
		}

		service.creatAccount(name, address, mobile, email);

		System.out
				.println("----Account Created Successfully----\nYour Details Are as Follows");

		System.out.println(service.displayCustomer());

		System.out.println("Done");

		while (true) {
			System.out.println("-----Choose a service-----");
			System.out.println("1.Show Balance");
			System.out.println("2.Deposit");
			System.out.println("3.Withdraw");
			System.out.println("4.Fund Transfer");
			System.out.println("5.Print Transaction");
			System.out.println("6.Exit Application");

			System.out.println("\nEnter your Choice");

			int choiceI;
			choiceI = sc.nextInt();

			switch (choiceI) {
			case 1:
				System.out.println("\n----1. Show balance------");
				System.out.println("Your balance is");
				service.showBalance();
				break;
			case 2:
				System.out.println("\n-------2. Deposit Amount-----");
				System.out.println("Enter amount to deposit ");
				double amountD = sc.nextDouble();
				service.depost(amountD);
				System.out.println("Amount deposited successfully");
				break;
			case 3:
				System.out.println("-----3 Withdraw Amount--------");
				while (true) {
					System.out.println("Enter Amount to withdraw ");
					double amountW = sc.nextDouble();
					service.withdraw(amountW);
					break;
				}
				break;
			case 4:
				System.out.println("\n------4. Fund Transfer--------");
				System.out.println("Enter Customer Detail For Fund Transfer ");
				System.out.println("Enter Account number to transfer fund    ");
				long accnt = sc.nextLong();
				System.out.println("Enter amount ");
				double amountT = sc.nextDouble();
				service.fundTransfer(accnt, amountT);
				break;
			case 5:
				System.out.println("------5. Print Transaction------");
				service.printSummary();
				
				
				
				break;
			case 6:
				System.out.println("\tThank you");
				System.out.println("You are out of application!!");
				System.exit(0);
			default:
				System.out
						.println("------------Enter Proper choice-----------");

			}

		}
	}

}
