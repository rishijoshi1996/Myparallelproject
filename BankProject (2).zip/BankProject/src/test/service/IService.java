package test.service;

import java.util.Map;

import test.bean.Customer;

public interface IService {
	String choicePattern = "[1-2]{1}";
	String namePattern = "[A-Z][ a-z]{2,20}";
	String addressPattern = "[A-Z a-z ]{3,20}";
	String mobilePattern = "[1-9]{1}[0-9]{9}";
	String emailPattern = "[A-z]{3,15}[@]{1}[A-z]{3,10}[.]{1}[c,o,m]{3}";

	boolean validateName(String name);

	boolean validateAddress(String address);

	boolean validateMobile(String mobile);

	boolean validateEmail(String email);

	boolean validateChoice(String choice);

	void creatAccount(String name, String address, String mobile, String email);
	
	Map<Integer, Customer> displayCustomer ();
	
	void showBalance();

	void depost(double amount);

	void withdraw(double amount);
	
	void fundTransfer(long acnt, double amount);
	
	void printSummary();
	
}
