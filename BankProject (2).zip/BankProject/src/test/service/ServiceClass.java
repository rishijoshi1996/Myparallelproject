package test.service;

import java.util.Map;

import test.bean.Customer;
import test.dao.ServiceDao;

public class ServiceClass implements IService {
	ServiceDao serviceDao = new ServiceDao();

	// Validate choice

	@Override
	public boolean validateChoice(String choice) {
		if (choice.matches(choicePattern))
			return true;
		else
			return false;
	}

	// Validate name
	@Override
	public boolean validateName(String name) {
		if (name.matches(namePattern)) {
			return true;
		} else
			return false;
	}

	// Validate address
	@Override
	public boolean validateAddress(String address) {
		if (address.matches(address))
			return true;
		else
			return false;
	}

	// Validate mobile
	@Override
	public boolean validateMobile(String mobile) {
		if (mobile.matches(mobilePattern))
			return true;
		else
			return false;
	}

	// Validate mobile
	@Override
	public boolean validateEmail(String email) {
		if (email.matches(email))
			return true;
		return false;
	}

	// Create account
	@Override
	public void creatAccount(String name, String address, String mobile,
			String email) {
		serviceDao.creatAccount();
		serviceDao.creatAccount(name, address, mobile, email);

	}

	// Display balance
	@Override
	public void showBalance() {
		serviceDao.showBalance();
	}

	// Deposit
	@Override
	public void depost(double amount) {
		serviceDao.storeBalance(amount);

	}

	// Withdraw
	@Override
	public void withdraw(double amount) {
		serviceDao.withdrawBalance(amount);

	}

	// Display customer
	@Override
	public Map<Integer, Customer> displayCustomer() {
		return serviceDao.displayCustomer();

	}

	@Override
	public void fundTransfer(long acnt, double amount) {
		serviceDao.fundTransfer(acnt, amount);

	}

	@Override
	public void printSummary() {
		serviceDao.printTransaction();
	}

}
