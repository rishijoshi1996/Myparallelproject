package test.dao;

import java.util.Map;

import test.bean.Customer;

public interface IServiceDao {

	Map<Integer, Customer> creatAccount();

	Map<Integer, Customer> displayCustomer();

	void creatAccount(String name, String address, String mobile, String email);

	void showBalance();

//	void deposit(double amount);
	
	void fundTransfer (long accnt, double amount);
	
	void printTransaction();
	

}
