package test.dao;

import java.util.HashMap;
import java.util.Map;

import test.bean.Customer;
import test.bean.TransactionsSummary;

public class ServiceDao implements IServiceDao {
	int idx ;
	Customer cust = new Customer();

	Map<Integer, Customer> mapDeti = new HashMap<Integer, Customer>();

	Map<Integer, Double> mapBal = new HashMap<Integer, Double>();

	TransactionsSummary[] txns;

	// To store user details
	@Override
	public Map<Integer, Customer> creatAccount() {
		mapDeti.put(cust.getCustId(), cust);
		return null;
	}

	// To Deposit balance
	public void storeBalance(double amount) {
		cust.setBalance(cust.getBalance() + amount);
		mapBal.put(cust.getCustId(), cust.getBalance());
		txns[idx++] = new TransactionsSummary("CR", amount, cust.getBalance());
	}

	// To withdraw balance
	public void withdrawBalance(double amount) {
		if (amount <= cust.getBalance()) {
			cust.setBalance(cust.getBalance() - amount);
			mapBal.put(cust.getCustId(), cust.getBalance());
			txns[idx++] = new TransactionsSummary("WD", amount, cust.getBalance());
		} else
			System.out.println("You do not have sufficient balance");
	}

	@Override
	public void creatAccount(String name, String address, String mobile,
			String email) {
		cust.setName(name);
		cust.setAddress(address);
		cust.setMobile(mobile);
		cust.setEmail(email);

		// Generate customer id auto

		int custId = (int) (Math.random() * 50);
		cust.setCustId(custId);

		txns = new TransactionsSummary[10]; // creates an array of transaction
											// type references

		double amount = 0;

		
		txns[idx++] = new TransactionsSummary("CR",amount, cust.getBalance());

	}

	// Show customer details
	@Override
	public Map<Integer, Customer> displayCustomer() {
		return mapDeti;
	}

	// Display Account balance
	@Override
	public void showBalance() {
		System.out.println(cust.getBalance());

	}

	// // deposit balance
	// @Override
	// public void deposit(double amount) {
	// mapDeti.get(amount);
	// }

	@Override
	public void fundTransfer(long accnt, double amount) {
		if (amount <= cust.getBalance()) {
			cust.setBalance(cust.getBalance() - amount);
			mapBal.put(cust.getCustId(), cust.getBalance());
			txns[idx++] = new TransactionsSummary("FT", amount, cust.getBalance());
		} else
			System.out.println("You do not have sufficient balance");

	}

	@Override
	public void printTransaction() {
		for (int i=0;i<idx;i++)
		System.out.println(txns[i].print());
		
	}

}
