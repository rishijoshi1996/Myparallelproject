package test.bean;


public class Customer {
	private String name;
	private String mobile;
	private double balance;
	private String address;
	private int custId;
	private String email;

	protected TransactionsSummary[] txns; // reference of transactions point to stack

	protected int idx;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "\nCustomer Id = " + custId + "\nName=" + name
				+ "\nMobile Number = " + mobile + "\nAddress = " + address
				+ "\nBalance = " + balance + "\nEmailId = " + email + "\n";
	}
	
	public void printTransaction(){
		System.out.println("Transaction of Customer  "+ custId );
		for (int i=0;i<idx;i++)
		System.out.println(( txns[i]).print());
	}

}
