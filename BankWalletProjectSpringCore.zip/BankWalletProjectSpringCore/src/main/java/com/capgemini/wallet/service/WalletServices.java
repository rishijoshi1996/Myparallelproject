package com.capgemini.wallet.service;

import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;

import com.capgemini.wallet.bean.AccountUser;
import com.capgemini.wallet.dao.AccountUserDao;


@Service
public class WalletServices implements IWalletServices {

	private AccountUserDao aud ;
	
	public void initService(ApplicationContext ctx) {
		aud=ctx.getBean(AccountUserDao.class);
		
	}


	public boolean validateUserName(String userName) {
		if (userName.matches(userNamePattern))
			return true;
		else
			return false;
	}

	public boolean validateUserAge(String userAge) {
		if (userAge.matches(userAgePattern) && Integer.parseInt(userAge) >= 22)
			return true;
		else
			return false;
	}

	public boolean validateUserAddress(String userAddress) {
		if (userAddress.matches(userAddressPattern))
			return true;
		else
			return false;
	}

	public boolean validateUserEmailAddress(String userEmailAddress) {
		if (userEmailAddress.matches(userEmailAddressPattern))
			return true;
		else
			return false;
	}

	public boolean validateChoice(String option) {
		if (option.matches(CHOICE))
			return true;
		else
		return false;
	}

	public boolean validateChoice1(String option1) {
		if (option1.matches(CHOICE1))
			return true;
		else
		return false;
	}

	public void showBalance() {
		aud.showBalance();		
	}

	public void depositMoney(double amount) {
		aud.depositMoney(amount);		
	}

	public void withdrawMoney(double amount) {
		aud.withdrawMoney(amount);		
	}

	public void fundTransfer(double amount) {
		aud.fundTransfer(amount);		
	}

	public void printTransaction() {
		aud.printTransaction();		
	}

	public void createUser(String name, String age, String address, String email) {
		aud.createUser(name, age, address, email);		
	}

	public void storeIntoMap() {
		aud.storeIntoMap();		
	}

	public Map<Integer, AccountUser> displayCustomer() {
		return null;
	}

	


	

	

}
